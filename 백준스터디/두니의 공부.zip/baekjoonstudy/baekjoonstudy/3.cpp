#include <string>
#include <vector>
#include<iostream>
using namespace std;


int main() {


}